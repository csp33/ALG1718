#!/usr/bin/gnuplot

set terminal png size 640,480

set output 'bb6.png'
plot 'bb6.tsp' using 2:3 with linespoints

set output 'bb7.png'
plot 'bb7.tsp' using 2:3 with linespoints

set output 'bb8.png'
plot 'bb8.tsp' using 2:3 with linespoints

set output 'bb9.png'
plot 'bb9.tsp' using 2:3 with linespoints

set output 'bb10.png'
plot 'bb10.tsp' using 2:3 with linespoints

set output 'bb11.png'
plot 'bb11.tsp' using 2:3 with linespoints

set output 'bb12.png'
plot 'bb12.tsp' using 2:3 with linespoints

set output 'bb13.png'
plot 'bb13.tsp' using 2:3 with linespoints

set output 'bb14.png'
plot 'bb14.tsp' using 2:3 with linespoints

set output 'bb15.png'
plot 'bb15.tsp' using 2:3 with linespoints

set output 'bb16.png'
plot 'bb16.tsp' using 2:3 with linespoints
