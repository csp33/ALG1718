#!/bin/bash

echo "Ejecutando tres heurísticas..."
./ejecucion_tres_heuristicas.sh

echo "Ejecutando mejor opción..."
./ejecucion_mejor_opcion.sh

echo "Ejecutando gnuplot..."
./gnuplot.sh