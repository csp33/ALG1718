#!/bin/bash

./calcular_distancia ../datosTSP/a280.tsp ../datosTSP/a280.opt.tour
./calcular_distancia ../datosTSP/att48.tsp ../datosTSP/att48.opt.tour
./calcular_distancia ../datosTSP/berlin52.tsp ../datosTSP/berlin52.opt.tour
./calcular_distancia ../datosTSP/ch130.tsp ../datosTSP/ch130.opt.tour
./calcular_distancia ../datosTSP/gr96.tsp ../datosTSP/gr96.opt.tour
./calcular_distancia ../datosTSP/lin105.tsp ../datosTSP/lin105.opt.tour
./calcular_distancia ../datosTSP/pa561.tsp ../datosTSP/pa561.opt.tour
./calcular_distancia ../datosTSP/st70.tsp ../datosTSP/st70.opt.tour
./calcular_distancia ../datosTSP/pr76.tsp ../datosTSP/pr76.opt.tour
./calcular_distancia ../datosTSP/rd100.tsp ../datosTSP/rd100.opt.tour
./calcular_distancia ../datosTSP/tsp225.tsp ../datosTSP/tsp225.opt.tour
./calcular_distancia ../datosTSP/ulysses16.tsp ../datosTSP/ulysses16.opt.tour
