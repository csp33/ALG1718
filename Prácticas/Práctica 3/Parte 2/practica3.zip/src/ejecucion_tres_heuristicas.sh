#!/bin/bash

./tsp ../datosTSP/a280.tsp
./tsp ../datosTSP/att48.tsp
./tsp ../datosTSP/berlin52.tsp
./tsp ../datosTSP/ch130.tsp
./tsp ../datosTSP/gr96.tsp
./tsp ../datosTSP/lin105.tsp
./tsp ../datosTSP/pa561.tsp
./tsp ../datosTSP/st70.tsp
./tsp ../datosTSP/pr76.tsp
./tsp ../datosTSP/rd100.tsp
./tsp ../datosTSP/tsp225.tsp
./tsp ../datosTSP/ulysses16.tsp
